import { logout } from '../api/data.js';
import { page, render } from '../lib.js';
import { getUserData } from '../util.js';

const root = document.getElementById('main-content');
document.getElementById('logoutBtn').addEventListener('click', onLogout);

export default function decorateContext(ctx, next) {
    ctx.render = (content) => render(content, root);
    ctx.updateUserNav = updateUserNav; //

    next();
}

export function updateUserNav() { 
    const userData = getUserData();

    if (userData) {
        document.getElementById('guestLogin').style.display = 'none';
        document.getElementById('guestReg').style.display = 'none';
        document.getElementById('createUser').style.display = 'inline-block';
        document.getElementById('logoutBtn').style.display = 'inline-block';

    } else {
        document.getElementById('guestLogin').style.display = 'inline-block';
        document.getElementById('guestReg').style.display = 'inline-block';
        document.getElementById('createUser').style.display = 'none';
        document.getElementById('logoutBtn').style.display = 'none';
    }
}

function onLogout() {
    logout();
    updateUserNav();
    page.redirect('/');
}