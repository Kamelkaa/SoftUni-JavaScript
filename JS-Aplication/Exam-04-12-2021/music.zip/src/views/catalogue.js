import { getAllMusics } from '../api/data.js';
import { html } from '../lib.js';
import { getUserData } from '../util.js';


const catalogueTemplate = (musics, detailsButtons) => html`
<section id="catalogPage">
    <h1>All Albums</h1>
    ${musics.length == 0
        ? html`<p>No Albums in Catalog!</p>`
        : detailsButtons(musics)}

</section>`;

const musicPriviewUsers = (music) => html`
<div class="card-box">
    <img src=${music.imgUrl}>
    <div>
        <div class="text-center">
            <p class="name">Name: ${music.name}</p>
            <p class="artist">Artist: ${music.artist}</p>
            <p class="genre">Genre: ${music.genre}</p>
            <p class="price">Price: $${music.price}</p>
            <p class="date">Release Date: ${music.releaseDate}</p>
        </div>
        <div class="btn-group">
            <a href="/details/${music._id}" id="details">Details</a>
        </div>
    </div>
</div>`;

const musicPriviewGuests = (music) => html`
<div class="card-box">
    <img src=${music.imgUrl}>
    <div>
        <div class="text-center">
            <p class="name">Name: ${music.name}</p>
            <p class="artist">Artist: ${music.artist}</p>
            <p class="genre">Genre: ${music.genre}</p>
            <p class="price">Price: $${music.price}</p>
            <p class="date">Release Date: ${music.releaseDate}</p>
        </div>
    </div>
</div>`;




export async function cataloguePage(ctx) {
    const musics = await getAllMusics();

    ctx.render(catalogueTemplate(musics, detailsButtons));
}

function detailsButtons(musics) {
    const userData = getUserData();
    return userData
        ? musics.map(musicPriviewUsers)
        : musics.map(musicPriviewGuests);
}