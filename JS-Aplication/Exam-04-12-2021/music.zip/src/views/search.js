import { SearchByMusicAlbum } from '../api/data.js';
import { html } from '../lib.js';
import { getUserData } from '../util.js';


const searchTemplate = (findeMusicAlbum, onSearch, params = '', detailsButtons) => html`
<section id="searchPage">
    <h1>Search by Name</h1>

    <div class="search">
        <input id="search-input" type="text" name="search" placeholder="Enter desired albums's name" .value=${params}>
        <button @click=${onSearch} class="button-list">Search</button>
    </div>

    <h2>Results:</h2>

    <!--Show after click Search button-->
    <div class="search-result">
        <!--If have matches-->
        ${findeMusicAlbum.length == 0
            ? html`<p class="no-result">No result.</p>`
            : detailsButtons(findeMusicAlbum)}

    </div>
</section>`;


const searchCardUsers = (music) => html`
<div class="card-box">
    <img src=${music.imgUrl}>
    <div>
        <div class="text-center">
            <p class="name">Name: ${music.name}</p>
            <p class="artist">Artist: ${music.artist}</p>
            <p class="genre">Genre: ${music.genre}</p>
            <p class="price">Price: $${music.price}</p>
            <p class="date">Release Date: ${music.releaseDate}</p>
        </div>
        <div class="btn-group">
            <a href="/details/${music._id}" id="details">Details</a>
        </div>
    </div>
</div>`;

const searchCardGuests = (music) => html`
<div class="card-box">
    <img src=${music.imgUrl}>
    <div>
        <div class="text-center">
            <p class="name">Name: ${music.name}</p>
            <p class="artist">Artist: ${music.artist}</p>
            <p class="genre">Genre: ${music.genre}</p>
            <p class="price">Price: $${music.price}</p>
            <p class="date">Release Date: ${music.releaseDate}</p>
        </div>
    </div>
</div>`;

export async function searchPage(ctx) {
    const params = ctx.querystring.split('=')[1];                    
    let findeMusicAlbum = [];                                        

    if (params) {                                                     
        findeMusicAlbum = await SearchByMusicAlbum(decodeURIComponent(params)); 
    }

    ctx.render(searchTemplate(findeMusicAlbum, onSearch, params, detailsButtons));


    function onSearch(event) {
        event.preventDefault();

        const searchElement = event.target.parentElement.querySelector('#search-input').value;

        if (searchElement) {
            ctx.page.redirect('/search?query=' + encodeURIComponent(searchElement));
        }else{
            alert('Write name of album befor click on Search!');
        }
    }
}

function detailsButtons(findeMusicAlbum) {
    const userData = getUserData();
    return userData
        ? findeMusicAlbum.map(searchCardUsers)
        : findeMusicAlbum.map(searchCardGuests);
}