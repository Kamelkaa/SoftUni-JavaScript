import { deleteMusic, getMusicById } from '../api/data.js';
import { html } from '../lib.js';
import { getUserData } from '../util.js';


const detailsTemplate = (music, isOwner, onDelete) => html`
<section id="detailsPage">
    <div class="wrapper">
        <div class="albumCover">
            <img src=${music.imgUrl}>
        </div>
        <div class="albumInfo">
            <div class="albumText">

                <h1>Name: ${music.name}</h1>
                <h3>Artist: ${music.artist}</h3>
                <h4>Genre: ${music.genre}</h4>
                <h4>Price: $${music.price}</h4>
                <h4>Date: ${music.releaseDate}</h4>
                <p>Description: ${music.description}</p>
            </div>

            ${musicControlsTemplate(music, isOwner, onDelete)}
        </div>
    </div>
</section>`;

const musicControlsTemplate = (music, isOwner, onDelete) => {
    if (isOwner) {
        return html`
        <div class="actionBtn">
            <a href="/edit/${music._id}" class="edit">Edit</a>
            <a @click=${onDelete} href="javascript:void(0)" class="remove">Delete</a>
        </div>`;
    } else {
        return null;
    }
};

export async function detailsPage(ctx) {
    const userData = getUserData();

    const music = await getMusicById(ctx.params.id);

    const isOwner = userData && userData.id == music._ownerId;

    ctx.render(detailsTemplate(music, isOwner, onDelete));

    async function onDelete() {
        const choice = confirm(`Are you sure you want to delete ${music.name}?`);

        if (choice) {
            await deleteMusic(ctx.params.id);
            ctx.page.redirect('/catalogue');
        }
    }
}